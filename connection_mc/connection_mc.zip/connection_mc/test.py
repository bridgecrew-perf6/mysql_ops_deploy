

list_a=[100,200,1,2,3,4]

#
def f1(list_a):
    list_a = sorted(list_a)
    res = 0
    for i,m in enumerate(list_a):
        diff_list = [m]
        for j,n in enumerate(list_a[i+1:]):
         #   print(n,m,n-m,j)
            if n-m == j+1:
                diff_list.append('1')
        if len(diff_list) > res:
            res = len(diff_list)
    return res
        
    

if __name__ == "__main__":
    list_a=[100,200,1,2,3,4]
    print(f1(list_a))